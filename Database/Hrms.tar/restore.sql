--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Hrms";
--
-- Name: Hrms; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Hrms" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE "Hrms" OWNER TO postgres;

\connect "Hrms"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: candidate_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.candidate_users (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    surname character varying(50) NOT NULL,
    national_identity character varying(11) NOT NULL,
    birth_year character varying(4) NOT NULL,
    verify boolean
);


ALTER TABLE public.candidate_users OWNER TO postgres;

--
-- Name: candidate_users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.candidate_users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.candidate_users_user_id_seq OWNER TO postgres;

--
-- Name: candidate_users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.candidate_users_user_id_seq OWNED BY public.candidate_users.id;


--
-- Name: confirm_employer_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.confirm_employer_users (
    id integer NOT NULL,
    employer_id integer NOT NULL,
    confirmed_staff_user integer,
    confirmed_date timestamp with time zone,
    is_confirmed boolean
);


ALTER TABLE public.confirm_employer_users OWNER TO postgres;

--
-- Name: confirm_employer_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.confirm_employer_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.confirm_employer_users_id_seq OWNER TO postgres;

--
-- Name: confirm_employer_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.confirm_employer_users_id_seq OWNED BY public.confirm_employer_users.id;


--
-- Name: employer_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employer_users (
    user_id integer NOT NULL,
    company_name character varying(100) NOT NULL,
    web_address character varying(50) NOT NULL,
    phone_number character varying(11) NOT NULL,
    verify boolean,
    user_confirm boolean
);


ALTER TABLE public.employer_users OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: job_positions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_positions (
    id integer NOT NULL,
    "position" character varying NOT NULL
);


ALTER TABLE public.job_positions OWNER TO postgres;

--
-- Name: job_positions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.job_positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_positions_id_seq OWNER TO postgres;

--
-- Name: job_positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.job_positions_id_seq OWNED BY public.job_positions.id;


--
-- Name: staff_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff_users (
    user_id integer NOT NULL,
    name character varying NOT NULL,
    surname character varying NOT NULL,
    verify boolean
);


ALTER TABLE public.staff_users OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    mail character varying(50) NOT NULL,
    password character varying(16) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: verify_candidate_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verify_candidate_users (
    id integer NOT NULL,
    candidate_id integer NOT NULL
);


ALTER TABLE public.verify_candidate_users OWNER TO postgres;

--
-- Name: verify_code; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verify_code (
    id integer NOT NULL,
    verify_code character varying NOT NULL,
    is_confirmed boolean,
    created_date date,
    confirmed_date date
);


ALTER TABLE public.verify_code OWNER TO postgres;

--
-- Name: verify_code_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verify_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.verify_code_id_seq OWNER TO postgres;

--
-- Name: verify_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verify_code_id_seq OWNED BY public.verify_code.id;


--
-- Name: verify_employer_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verify_employer_users (
    id integer NOT NULL,
    employer_id integer NOT NULL
);


ALTER TABLE public.verify_employer_users OWNER TO postgres;

--
-- Name: verify_employer_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verify_employer_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.verify_employer_users_id_seq OWNER TO postgres;

--
-- Name: verify_employer_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verify_employer_users_id_seq OWNED BY public.verify_employer_users.id;


--
-- Name: verify_staff_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verify_staff_users (
    id integer NOT NULL,
    staff_id integer NOT NULL
);


ALTER TABLE public.verify_staff_users OWNER TO postgres;

--
-- Name: verify_staff_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verify_staff_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.verify_staff_users_id_seq OWNER TO postgres;

--
-- Name: verify_staff_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verify_staff_users_id_seq OWNED BY public.verify_staff_users.id;


--
-- Name: candidate_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_users ALTER COLUMN id SET DEFAULT nextval('public.candidate_users_user_id_seq'::regclass);


--
-- Name: confirm_employer_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirm_employer_users ALTER COLUMN id SET DEFAULT nextval('public.confirm_employer_users_id_seq'::regclass);


--
-- Name: job_positions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_positions ALTER COLUMN id SET DEFAULT nextval('public.job_positions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: verify_code id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_code ALTER COLUMN id SET DEFAULT nextval('public.verify_code_id_seq'::regclass);


--
-- Name: verify_employer_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_employer_users ALTER COLUMN id SET DEFAULT nextval('public.verify_employer_users_id_seq'::regclass);


--
-- Name: verify_staff_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_staff_users ALTER COLUMN id SET DEFAULT nextval('public.verify_staff_users_id_seq'::regclass);


--
-- Data for Name: candidate_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.candidate_users (id, name, surname, national_identity, birth_year, verify) FROM stdin;
\.
COPY public.candidate_users (id, name, surname, national_identity, birth_year, verify) FROM '$$PATH$$/3084.dat';

--
-- Data for Name: confirm_employer_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.confirm_employer_users (id, employer_id, confirmed_staff_user, confirmed_date, is_confirmed) FROM stdin;
\.
COPY public.confirm_employer_users (id, employer_id, confirmed_staff_user, confirmed_date, is_confirmed) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: employer_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employer_users (user_id, company_name, web_address, phone_number, verify, user_confirm) FROM stdin;
\.
COPY public.employer_users (user_id, company_name, web_address, phone_number, verify, user_confirm) FROM '$$PATH$$/3085.dat';

--
-- Data for Name: job_positions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_positions (id, "position") FROM stdin;
\.
COPY public.job_positions (id, "position") FROM '$$PATH$$/3088.dat';

--
-- Data for Name: staff_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff_users (user_id, name, surname, verify) FROM stdin;
\.
COPY public.staff_users (user_id, name, surname, verify) FROM '$$PATH$$/3086.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, mail, password) FROM stdin;
\.
COPY public.users (id, mail, password) FROM '$$PATH$$/3082.dat';

--
-- Data for Name: verify_candidate_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verify_candidate_users (id, candidate_id) FROM stdin;
\.
COPY public.verify_candidate_users (id, candidate_id) FROM '$$PATH$$/3091.dat';

--
-- Data for Name: verify_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verify_code (id, verify_code, is_confirmed, created_date, confirmed_date) FROM stdin;
\.
COPY public.verify_code (id, verify_code, is_confirmed, created_date, confirmed_date) FROM '$$PATH$$/3090.dat';

--
-- Data for Name: verify_employer_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verify_employer_users (id, employer_id) FROM stdin;
\.
COPY public.verify_employer_users (id, employer_id) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: verify_staff_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verify_staff_users (id, staff_id) FROM stdin;
\.
COPY public.verify_staff_users (id, staff_id) FROM '$$PATH$$/3093.dat';

--
-- Name: candidate_users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.candidate_users_user_id_seq', 1, false);


--
-- Name: confirm_employer_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.confirm_employer_users_id_seq', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 23, true);


--
-- Name: job_positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.job_positions_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 25, true);


--
-- Name: verify_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verify_code_id_seq', 1, false);


--
-- Name: verify_employer_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verify_employer_users_id_seq', 1, false);


--
-- Name: verify_staff_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verify_staff_users_id_seq', 1, false);


--
-- Name: candidate_users candidate_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_users
    ADD CONSTRAINT candidate_users_pkey PRIMARY KEY (id);


--
-- Name: confirm_employer_users confirm_employer_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirm_employer_users
    ADD CONSTRAINT confirm_employer_users_pkey PRIMARY KEY (id);


--
-- Name: employer_users employer_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_users
    ADD CONSTRAINT employer_users_pkey PRIMARY KEY (user_id);


--
-- Name: job_positions job_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_positions
    ADD CONSTRAINT job_positions_pkey PRIMARY KEY (id);


--
-- Name: staff_users staff_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_pkey PRIMARY KEY (user_id);


--
-- Name: candidate_users uk_identity_number; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_users
    ADD CONSTRAINT uk_identity_number UNIQUE (national_identity);


--
-- Name: users uk_mail; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_mail UNIQUE (mail);


--
-- Name: job_positions uk_position; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_positions
    ADD CONSTRAINT uk_position UNIQUE ("position");


--
-- Name: verify_code uk_verify_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_code
    ADD CONSTRAINT uk_verify_code UNIQUE (verify_code);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verify_candidate_users verify_candidate_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_candidate_users
    ADD CONSTRAINT verify_candidate_users_pkey PRIMARY KEY (id);


--
-- Name: verify_code verify_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_code
    ADD CONSTRAINT verify_code_pkey PRIMARY KEY (id);


--
-- Name: verify_employer_users verify_employer_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_employer_users
    ADD CONSTRAINT verify_employer_users_pkey PRIMARY KEY (id);


--
-- Name: verify_staff_users verify_staff_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_staff_users
    ADD CONSTRAINT verify_staff_users_pkey PRIMARY KEY (id);


--
-- Name: candidate_users candidate_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_users
    ADD CONSTRAINT candidate_users_user_id_fkey FOREIGN KEY (id) REFERENCES public.users(id) NOT VALID;


--
-- Name: confirm_employer_users confirm_employer_users_confirmed_staff_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirm_employer_users
    ADD CONSTRAINT confirm_employer_users_confirmed_staff_user_fkey FOREIGN KEY (confirmed_staff_user) REFERENCES public.staff_users(user_id) NOT VALID;


--
-- Name: confirm_employer_users confirm_employer_users_employer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirm_employer_users
    ADD CONSTRAINT confirm_employer_users_employer_id_fkey FOREIGN KEY (employer_id) REFERENCES public.employer_users(user_id) NOT VALID;


--
-- Name: confirm_employer_users confirm_employer_users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.confirm_employer_users
    ADD CONSTRAINT confirm_employer_users_id_fkey FOREIGN KEY (id) REFERENCES public.verify_code(id) NOT VALID;


--
-- Name: employer_users employer_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employer_users
    ADD CONSTRAINT employer_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) NOT VALID;


--
-- Name: staff_users staff_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT staff_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) NOT VALID;


--
-- Name: verify_candidate_users verify_candidate_users_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_candidate_users
    ADD CONSTRAINT verify_candidate_users_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidate_users(id) NOT VALID;


--
-- Name: verify_candidate_users verify_candidate_users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_candidate_users
    ADD CONSTRAINT verify_candidate_users_id_fkey FOREIGN KEY (id) REFERENCES public.verify_code(id) NOT VALID;


--
-- Name: verify_employer_users verify_employer_users_employer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_employer_users
    ADD CONSTRAINT verify_employer_users_employer_id_fkey FOREIGN KEY (employer_id) REFERENCES public.employer_users(user_id) NOT VALID;


--
-- Name: verify_employer_users verify_employer_users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_employer_users
    ADD CONSTRAINT verify_employer_users_id_fkey FOREIGN KEY (id) REFERENCES public.verify_code(id) NOT VALID;


--
-- Name: verify_staff_users verify_staff_users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_staff_users
    ADD CONSTRAINT verify_staff_users_id_fkey FOREIGN KEY (id) REFERENCES public.verify_code(id) NOT VALID;


--
-- Name: verify_staff_users verify_staff_users_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verify_staff_users
    ADD CONSTRAINT verify_staff_users_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff_users(user_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

